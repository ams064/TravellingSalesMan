#include <iostream>
#include <vector>
#include "proj0.hpp"



int main()
{
	// Feel free to use main() as you desire, if that is your preference.
	// Remember grading is done via gtest not by manually running your program!
    return 0;
}

